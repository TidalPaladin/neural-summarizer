# neural-summarizer
Neural text summarization for CS6320 (Natural Language Processing)
Baseline implementation of BERTSUM provided
[here](https://github.com/nlpyang/BertSum).

Work in progress
